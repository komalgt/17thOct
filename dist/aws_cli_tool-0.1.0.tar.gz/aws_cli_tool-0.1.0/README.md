# AWS CLI Tool

A Python CLI tool to query AWS EC2 instance usage.

## Installation
```bash
pip install aws-cli-tool
